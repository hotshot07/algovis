__version__ = '0.1.0'

def HelloWorld():
    print("Hello :) This is my first package")
